<!-- Footer start-->
<footer>

		<hr class="delimiter_footer"> </hr>
		MAHESH BANGALORE KRISHNAPPA | s3576395 | WEB PROGRAMMING ASSIGNMENT 2
		<?php include_once("/home/eh1/e54061/public_html/wp/debug.php"); ?>
</footer>
<!-- Footer end-->