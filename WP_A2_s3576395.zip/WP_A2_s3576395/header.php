<header >
	<div class="header_content">
	
		<div class="header_left">
		</div>
		
		<div class="header_center">
			
			<a href="Design1_homepage.php">
				
				<!--
				Reference: Image - image_proj.jpg
				https://www.graphicsprings.com/start-your-logo
				-->
				<img class="img_header2" src="image\image_proj.jpg" alt="logo" > 
				
				<!--
				Reference: Image - logo_silver.png
				http://www4.flamingtext.com.au/net-fu/dynamic.cgi?script=space-logo&text=Silverado&fontname=Antilles+Laser+3D&textColor=%23000bf7&bevelWidth=4&backgroundRadio=0&jpgQuality=100&watermark=yes#customize
				-->
				<img class="img_header" src="image\logo_silver.png" alt="logo" > 
				</a>	
			
		</div>
		
		
		<div class="header_right">
		</div>
	</div>

</header>
